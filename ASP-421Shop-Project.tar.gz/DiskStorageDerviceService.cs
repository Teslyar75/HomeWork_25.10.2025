﻿internal class DiskStorageDerviceService
{
}